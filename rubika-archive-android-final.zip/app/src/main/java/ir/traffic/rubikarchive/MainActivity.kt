package ir.traffic.rubikarchive

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.OutputStreamWriter

class MainActivity : ComponentActivity() {
    private lateinit var store: MessageStore
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = MessageStore(this)
        setContent { ArchiveScreen(store) }
    }
}

@Composable
private fun ArchiveScreen(store: MessageStore) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var status by remember { mutableStateOf("برای شروع، فایل JSON پیام‌ها را وارد کن.") }
    var total by remember { mutableIntStateOf(store.count()) }
    var busy by remember { mutableStateOf(false) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            busy = true
            try {
                val result = ArchiveIO.importJson(context.contentResolver, uri, store)
                total = store.count()
                status = "گروه: ${result.chatTitle}\nتازه ذخیره‌شده: ${result.inserted}\nتکراری: ${result.duplicates}\nردشده: ${result.rejected}\nمجموع ذخیره‌شده: $total"
            } catch (e: Exception) {
                status = "خطا در خواندن JSON: ${e.message ?: "ساختار فایل معتبر نیست"}"
            } finally { busy = false }
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri: Uri? ->
        if (uri != null) {
            try {
                val html = ArchiveIO.exportHtml(store.allMessages())
                context.contentResolver.openOutputStream(uri)?.use { out -> OutputStreamWriter(out, Charsets.UTF_8).use { it.write(html) } }
                status = "خروجی HTML ذخیره شد. تعداد پیام‌ها: ${store.count()}"
            } catch (e: Exception) { status = "خطا در ساخت HTML: ${e.message}" }
        }
    }

    MaterialTheme {
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.Start) {
                    Text("آرشیو پیام‌های روبیکا", fontSize = 25.sp, style = MaterialTheme.typography.headlineMedium)
                    Text("ذخیرهٔ محلی و خروجی HTML فارسی", style = MaterialTheme.typography.titleMedium)
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("پیام‌های ذخیره‌شده: $total", style = MaterialTheme.typography.titleLarge)
                            Text("پیام‌های تکراری با شناسهٔ یکسان دوباره ذخیره نمی‌شوند.")
                        }
                    }
                    Button(onClick = { importLauncher.launch(arrayOf("application/json", "text/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("واردکردن فایل JSON پیام‌ها") }
                    Button(onClick = { exportLauncher.launch("rubika-archive.html") }, enabled = !busy && total > 0, modifier = Modifier.fillMaxWidth()) { Text("ساخت فایل HTML قابل جست‌وجو") }
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    HorizontalDivider()
                    Text("وضعیت", style = MaterialTheme.typography.titleMedium)
                    Text(status, textAlign = TextAlign.Start)
                    Text("مهم: این نسخه هنوز مستقیماً به روبیکا وصل نمی‌شود و تاریخچه را خودکار دریافت نمی‌کند. برای واردکردن داده، فایل JSON لازم است.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
