package ir.traffic.rubikarchive

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

 data class ArchiveMessage(
    val id: String,
    val chat: String,
    val sender: String,
    val timestamp: Long,
    val text: String
)

class MessageStore(context: Context) : SQLiteOpenHelper(context, "rubika_archive.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE messages (id TEXT PRIMARY KEY NOT NULL, chat TEXT NOT NULL, sender TEXT NOT NULL, timestamp INTEGER NOT NULL, text TEXT NOT NULL)")
        db.execSQL("CREATE INDEX idx_messages_time ON messages(timestamp)")
        db.execSQL("CREATE INDEX idx_messages_chat ON messages(chat)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun insertIfNew(message: ArchiveMessage): Boolean {
        val values = ContentValues().apply {
            put("id", message.id); put("chat", message.chat); put("sender", message.sender)
            put("timestamp", message.timestamp); put("text", message.text)
        }
        return writableDatabase.insertWithOnConflict("messages", null, values, SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }

    fun count(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM messages", null).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }

    fun allMessages(): List<ArchiveMessage> {
        val result = mutableListOf<ArchiveMessage>()
        readableDatabase.rawQuery("SELECT id, chat, sender, timestamp, text FROM messages ORDER BY timestamp ASC, id ASC", null).use { c ->
            while (c.moveToNext()) result.add(ArchiveMessage(c.getString(0), c.getString(1), c.getString(2), c.getLong(3), c.getString(4)))
        }
        return result
    }
}
