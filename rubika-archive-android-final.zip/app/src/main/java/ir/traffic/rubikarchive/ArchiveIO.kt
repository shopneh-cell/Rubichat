package ir.traffic.rubikarchive

import android.content.ContentResolver
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.security.MessageDigest

object ArchiveIO {
    data class ImportResult(val inserted: Int, val duplicates: Int, val rejected: Int, val chatTitle: String)

    fun importJson(resolver: ContentResolver, uri: Uri, store: MessageStore): ImportResult {
        val raw = resolver.openInputStream(uri)?.use { input -> BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText() }
            ?: throw IllegalArgumentException("فایل باز نشد")
        val root = JSONObject(raw)
        val chatTitle = root.optString("chat_title", root.optString("group", "گروه بدون نام"))
        val array = root.optJSONArray("messages") ?: root.optJSONArray("data") ?: JSONArray()
        var inserted = 0; var duplicates = 0; var rejected = 0
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i)
            if (item == null) { rejected++; continue }
            val text = item.optString("text", item.optString("message", ""))
            if (text.isBlank()) { rejected++; continue }
            val sender = item.optString("sender", item.optString("sender_name", item.optString("from_name", "نامشخص")))
            val timestamp = parseTimestamp(item.opt("timestamp") ?: item.opt("date") ?: item.opt("time"))
            val rawId = item.optString("id", item.optString("message_id", item.optString("msg_id", ""))).trim()
            val id = if (rawId.isNotEmpty() && rawId != "null") rawId else sha256("$chatTitle|$sender|$timestamp|$text")
            if (store.insertIfNew(ArchiveMessage(id, chatTitle, sender, timestamp, text))) inserted++ else duplicates++
        }
        return ImportResult(inserted, duplicates, rejected, chatTitle)
    }

    private fun parseTimestamp(value: Any?): Long {
        if (value == null || value == JSONObject.NULL) return 0L
        val s = value.toString().trim()
        s.toLongOrNull()?.let { return if (it > 100_000_000_000L) it / 1000 else it }
        val formats = listOf("yyyy-MM-dd'T'HH:mm:ss.SSSX", "yyyy-MM-dd'T'HH:mm:ssX", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd")
        for (pattern in formats) try { return SimpleDateFormat(pattern, Locale.US).parse(s)?.time?.div(1000) ?: 0L } catch (_: Exception) {}
        return 0L
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    fun exportHtml(messages: List<ArchiveMessage>): String {
        val rows = messages.joinToString("\n") { m ->
            val date = if (m.timestamp > 0) SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale("fa", "IR")).format(Date(m.timestamp * 1000)) else "زمان نامشخص"
            "<article class=\"message\" data-search=\"${esc(m.sender + " " + date + " " + m.text)}\"><header><strong>${esc(m.sender)}</strong><time>${esc(date)}</time></header><p>${esc(m.text).replace("\n", "<br>")}</p></article>"
        }
        return """<!doctype html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>آرشیو پیام‌ها</title>
<style>body{font-family:Tahoma,Arial,sans-serif;background:#f5f5f5;color:#222;max-width:900px;margin:auto;padding:16px}h1{font-size:1.4rem}#q{box-sizing:border-box;width:100%;padding:12px;border:1px solid #aaa;border-radius:8px;font-size:16px;position:sticky;top:8px}.message{background:#fff;border:1px solid #ddd;border-radius:9px;padding:12px;margin:10px 0;overflow-wrap:anywhere}.message header{display:flex;gap:12px;justify-content:space-between;flex-wrap:wrap;color:#555;font-size:.9rem}.message p{white-space:normal;line-height:1.9;margin-bottom:0}#count{color:#555}</style></head><body>
<h1>آرشیو پیام‌ها</h1><input id="q" type="search" placeholder="جست‌وجو در متن، فرستنده یا زمان…"><p id="count">${messages.size} پیام</p><main id="messages">$rows</main>
<script>const q=document.getElementById('q'),items=[...document.querySelectorAll('.message')],count=document.getElementById('count');function filter(){const s=q.value.toLocaleLowerCase();let n=0;for(const e of items){const show=e.dataset.search.toLocaleLowerCase().includes(s);e.hidden=!show;if(show)n++}count.textContent=n+' پیام';}q.addEventListener('input',filter);</script></body></html>"""
    }
    private fun esc(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;")
}
